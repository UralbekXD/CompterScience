public class HelloGoodbye {
    public static void main(String[] args) {
        String firstName = args[0];
        String secondName = args[1];

        // Prints Hello
        System.out.println("Hello " + firstName + " and " + secondName + ".");

        // Prints Goodbye
        System.out.println("Goodbye " + secondName + " and " + firstName + ".");
    }
}
